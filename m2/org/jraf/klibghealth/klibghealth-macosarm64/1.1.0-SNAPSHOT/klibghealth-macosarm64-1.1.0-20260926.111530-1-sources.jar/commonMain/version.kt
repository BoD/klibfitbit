// Generated file. Do not edit!
package org.jraf.klibghealth
import kotlin.jvm.JvmField
@JvmField
val VERSION = "1.1.0-SNAPSHOT"
