// Generated file. Do not edit!
package org.jraf.klibfitbit
import kotlin.jvm.JvmField
@JvmField
val VERSION = "1.0.3-SNAPSHOT"
